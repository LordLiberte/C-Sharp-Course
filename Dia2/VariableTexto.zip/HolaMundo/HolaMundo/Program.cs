﻿using System;

namespace HolaMundo
{
    class Program
    {
        static void Main(string[] args)
        {
            string MiNombre = "Denis";
            string mensaje = "Mi nombre es " + MiNombre;

            string MensMin = mensaje.ToLower();

            Console.WriteLine(MensMin);
            Console.Read();
        }
    }
}
