﻿using System;

namespace Clases___Basico
{
    class Program
    {
        static void Main(string[] args)
        {
            Humano luis = new Humano("Luis", "Garay", "Marrón", 42);
            Humano ana = new Humano("Ana", "Maina", "Verde", 1);

            luis.presentarme();
            ana.presentarme();

            Console.Read();
        }
    }
}
