﻿using System;

namespace Miembros
{
    class Program
    {
        static void Main(string[] args)
        {
            Miembros nuevoMiembro = new Miembros();
            nuevoMiembro.Amigo(true);

            Console.Read();
        }
    }
}
